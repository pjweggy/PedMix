//
//  PedigreeMixLikelihoodGeno.cpp
//
//
//  Created by Yufeng Wu on 3/25/15.
//
//

#include "PedigreeMixLikelihoodGeno.h"
